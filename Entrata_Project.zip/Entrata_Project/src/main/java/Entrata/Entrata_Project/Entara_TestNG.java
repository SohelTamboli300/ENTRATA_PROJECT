package Entrata.Entrata_Project;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.util.Set;

public class Entara_TestNG {

    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Set ChromeDriver
       WebDriverManager.chromedriver().setup();
    	// Initialize ChromeDriver
        driver = new ChromeDriver();
        // Navigate to Entrata_website
        driver.get("https://www.entrata.com");
        driver.manage().window().maximize();
    }

    @Test
    public void testLogin() throws InterruptedException {
    	String username="soheltamboli";
    	String password="12345";
    	// Accept cookies
        WebElement verifyCookie = driver.findElement(By.xpath("//button[@id='rcc-confirm-button']"));
        Assert.assertTrue(verifyCookie.isDisplayed());
        verifyCookie.click();

        // Open sign-in page in a new tab
        WebElement signInButton = driver.findElement(By.xpath("//a[@class='button-default outline-dark-button']"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].setAttribute('target','_blank');", signInButton);
        signInButton.click();

        // Switch to the new tab
        Set<String> windowHandles = driver.getWindowHandles();
        for (String handle : windowHandles) {
            driver.switchTo().window(handle);
        }

        // Scroll on the page
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1300)");

        // Click on 'Client Login'
        driver.findElement(By.xpath("//a[contains(@title,'Client Login')]")).click();

        
        // Perform login page
        driver.findElement(By.xpath("//input[@placeholder='Username']"))
        .sendKeys(username);
        driver.findElement(By.xpath("//input[@type='password']"))
        .sendKeys(password);
        
        
        //navigate to_homepage
        driver.switchTo().window((String) windowHandles.toArray()[0]);
        
        //to validate the visible text
       String value= driver.findElement(By.cssSelector("div[class='hero-left'] h1")).getText();
       Assert.assertEquals(value,"Enabling efficient operations");
      
        
        
    }
  
    
     @AfterClass
    public void Check() {
        // Close the browser
        if (driver != null) {
            driver.quit();
        }
    } 
}
